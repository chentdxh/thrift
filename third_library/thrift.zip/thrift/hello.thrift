service hello {
    void func1( )
}
